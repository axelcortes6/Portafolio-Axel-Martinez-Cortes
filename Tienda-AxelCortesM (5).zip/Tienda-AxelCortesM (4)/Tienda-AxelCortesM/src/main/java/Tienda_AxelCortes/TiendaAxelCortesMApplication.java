package Tienda_AxelCortes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaAxelCortesMApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaAxelCortesMApplication.class, args);
	}

}
