/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.axelcortes.tiendaAxelcortes.service;
import com.axelcortes.tiendaAxelcortes.domain.Categoria;
import com.axelcortes.tiendaAxelcortes.repository.CategoriaRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CategoriaService {

    @Autowired
    private CategoriaRepository categoriaRepository;

    @Transactional(readOnly = true)
    public List<Categoria> getCategorias(boolean activo) {
        if (activo) {
            return categoriaRepository.findByActivoTrue();
        }
        return categoriaRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Categoria getCategoria(Categoria categoria) {
        // Busca la categoría por su ID, si no la encuentra retorna null
        return categoriaRepository.findById(categoria.getIdCategoria()).orElse(null);
    }

    @Transactional
    public void save(Categoria categoria) {
        // Guarda o actualiza la categoría
        categoriaRepository.save(categoria);
    }

    @Transactional
    public void delete(Categoria categoria) {
        // Elimina la categoría
        categoriaRepository.delete(categoria);
    }
}
 